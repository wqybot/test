'''
File management.

Usage: githubot file upload --token=TOKEN --repo=REPO  [FILES...]
       githubot file download --token=TOKEN --repo=REPO  [FILES...]

Options:
    --token=TOKEN           Github access token.
    -r=REPO --repo=REPO     Repo full name like: owner/repo.
    -h --help               Show this message and exit.
'''

from docopt import docopt
from github import Github


def download_file(repo, filename):
    contents = repo.get_contents(filename)
    print(contents.encoding)
    print(contents.download_url)
    print(contents.name)
    print(contents.path)
    print(contents.type)
    print(contents.content)


def download_files(repo, files):
    for f in files:
        download_file(repo, f)


def file(token, repo, files):
    g = Github(token)
    repo = g.get_repo(repo)
    download_files(repo, files)


def main():
    args = docopt(__doc__)

    token = args['--token']
    repo = args['--repo']
    files = args['FILES']

    file(token, repo, files)


if __name__ == '__main__':
    download_file()